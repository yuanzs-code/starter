package com.yoso.autovalue;

/**
 * @author yuanzs
 * @date 2021年04月30日 15:11
 */
public class YosoAutoTest {

    public YosoAutoTest() {
        System.out.println("yoso自动配置启动成功");
    }
}
